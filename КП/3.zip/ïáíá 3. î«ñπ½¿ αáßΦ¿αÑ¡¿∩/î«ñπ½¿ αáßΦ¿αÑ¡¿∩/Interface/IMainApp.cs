﻿namespace Interface
{
    using System.Drawing;

    public interface IMainApp
    {
        Bitmap Image { get; set; }
    }
}
